# Krypt - Web 3.0 Blockchain Application
![Krypt](https://i.ibb.co/DVF4tNW/image.png)

## Introduction
This is a code repository for the corresponding video tutorial.

Using Web 3.0 methodologies, Solidity and Metamask you'll learn how to build a your first real Web 3.0 Application - from start to finish.

Project created in collaboration with Enyel Sequeira: 
Portfolio - https://www.enyelsequeira.com
E-mail - enyelsequeira1994@gmail.com
Want me to cover the project you've created? Send me an e-mail 👌

## Stay up to date with new projects
New major projects coming soon, subscribe to the mailing list to stay up to date https://jsmasterypro.com/newsletter
