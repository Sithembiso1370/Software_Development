 # React-projects

 
<ul>
  <li><h1>Single Channel Messanger</h1>
   <p><h3>Tools Used</h3><li>React(No Hooks)</li><li>Firebase</li><li>Material Ui</li> <li>Css</li></P>
   <img src="https://github.com/abodmicheal/React-projects/blob/master/Single-Channel-Messanger/public/20200825_112955.gif?raw=true" />
   <h4><a href="https://single-channel-messanger.web.app" target="_blank">Lauch Demo/Live Project</a></h4>
    
 <li><h1>Netflix UI Web App</h1>
   <p><h3>Tools Used</h3><li>React(No Hooks)</li><li>Css + BEM</li><li>Firebase(Hosting)</li><li>TMDB API</li><li>Material UI</li><li>React Movie-Trailer</li><li>React-Youtube</li><li>Axios JS</li></P>
     <img src="https://github.com/abodmicheal/React-projects/blob/master/gifs/20200915_142422.gif?raw=true" />
     <h6>Used a library to fetch previews but The Netflix original and main banner has no preview,  click play on other categories </h6>
     <h4><a href="https://netflix-clone-dd230.web.app/" target="_blank">Lauch Demo/Live Project</a></h4>

   <li><h1>Home/Vacation Rentals - Airbnb UI</h1>
    <p><h3>Tools Used</h3><li>React(No Hooks)</li><li>React Router(Static & Dynamic)</li><li>Firebase(Hosting)</li><li>Material Ui</li><li>Css</li><li>react-dates</li><li>Json</li></P>
    <img src="https://github.com/abodmicheal/React-projects/blob/master/gifs/20201103_184656.gif?raw=true" />
    <h4><a href="https://abod-bnb.web.app/" target="_blank">Lauch Demo/Live Project</a></h4>

   <li><h1>Ecommerce Web App</h1>
   <p><h3>Tools Used</h3><li>React + Hooks</li><li>Firebase + User authentication</li><li>Css</li><li>Redux</li><li>React ROUTER</li><li>Material Ui</li><li>React paypal button</li><li>Paypal Payment</li><li>AOS</li></P>
   <img src="https://github.com/abodmicheal/React-projects/blob/master/gifs/20210820_222112.gif?raw=true" />
   <h4><a href="https://abod-zone.web.app/" target="_blank">Lauch Demo/Live Project</a></h4>
