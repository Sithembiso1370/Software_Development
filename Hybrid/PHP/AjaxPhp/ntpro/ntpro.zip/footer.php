	<div class="footer-section">
						<div class="container">
							<div class="footer-grids">
								<div class="col-xs-5 footer-grid">
									<h4>About NT-Pro</h4>
									<p>We support and maintain entity in the automation and control industry. 
									It is formed to re sell, support and maintain, repair SEW products, Servo motors,
									Frequency invertors, Geared motors and industrial gear units. 
									We intend to put the customer first, prevent breakdowns the best possible and to ensure
									that production never stops in the manufacturing and production plants.</p>
								</div>
								<div class="col-xs-13 footer-grid">
									<h4>Our Services</h4>
									<ul>
										<li><a href="services.php">Installation and commissioning</a></li>
										<li><a href="services.php">Onsite support and online support</a></li>
										<li><a href="services.php">On Demand Routine Maintenance </a></li>
										<li><a href="services.php"> Repairs</a></li>
										<li><a href="services.php">Free Solution Modelling</a></li>
										<li><a href="services.php">Free Product Training </a></li>
									</ul>
								</div>
								<div class="col-xs-13 footer-grid">
									<h4>Get In Touch</h4>
									<p>8094 Sugarbird Cresent, Etwatwa</p>
									<p>Daveyton, Benoni</p>
									<p>Gauteng</p>
									<p>1519</p>
									<p>TEL : +27 11 962 9102</p>
									<p>CELL: +27 67 669 9145</p>
									<p>E-mail : <a href="mailto:info@ntpro.com"> info@ntpro.co.za</a></p>
								</div>
							<div class="clearfix"> </div>
							</div>
							
						</div>
					</div>