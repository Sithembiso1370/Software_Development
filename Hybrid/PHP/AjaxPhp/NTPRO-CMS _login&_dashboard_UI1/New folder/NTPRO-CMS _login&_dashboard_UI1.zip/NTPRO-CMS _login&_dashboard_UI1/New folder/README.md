# dashboard-ui-sidebar
Implementação da estrutura de um Dashboard com barra de navegação lateral
