<?php
//database_connection.php
$connect = new PDO('mysql:host=localhost;dbname=ntproesu_ntprodb', 'ntproesu_ntprocms', '21213131$Nt');


?>